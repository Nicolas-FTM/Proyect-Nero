package Ajustes;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.nero.R;

public class ModificarFuente extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar_fuente);
    }
}