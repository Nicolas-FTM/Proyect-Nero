package PaqueteReporteFactoryMethod;

public interface Factory {
    public Reporte getReporte(String tipoReporte);
}
