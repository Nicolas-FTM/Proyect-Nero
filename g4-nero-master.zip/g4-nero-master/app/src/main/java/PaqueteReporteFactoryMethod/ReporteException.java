package PaqueteReporteFactoryMethod;

public class ReporteException extends RuntimeException {
    public ReporteException(String mensaje) {
        super(mensaje);
    }
}
