﻿## NERO
### Miembros
- Juan Andrés Pareja Ballesteros (Arquitecto y Tester).
- Merlin Daniel Siering (Arquitecto y Desarrollador).
- Nicolás Felipe Trujillo Montero (Coordinador y Analista).
- Francisco Pérez Moreno (Coordinador y Analista).
- Rafael Rueda Rodriguez (Coordinador y Analista).
- Elio Jimenez Luque (Analista y Tester).
- Alvaro Lopera Mendizabal (Coordinador, Desarrollador y Analista).

### Descripcion
Este software está enfocado a cualquier persona que sienta la necesidad de beber agua y no encuentre suministro de ella. Es decir, mayoritariamente se centraría en senderistas realizando rutas por la montaña o gente extranjera que viene de visita a un lugar. En definitiva para cualquier persona que necesite una fuente de agua potable.
